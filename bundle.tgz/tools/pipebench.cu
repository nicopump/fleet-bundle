// microbenchmark a cicli: istruzioni per clock per SM, per capire su quali pipe girano LOP3 / SHF / IMAD
#include <cstdio>
#include <cuda_runtime.h>
#define N 16
__constant__ unsigned c_pow[32];
#define MAX_SM_ID 512
__device__ unsigned long long g_start[MAX_SM_ID], g_end[MAX_SM_ID];

__device__ __forceinline__ unsigned smid() { unsigned r; asm volatile("mov.u32 %0, %%smid;" : "=r"(r)); return r; }
__device__ __forceinline__ unsigned lop(unsigned a, unsigned b, unsigned c) {
    unsigned r; asm volatile("lop3.b32 %0, %1, %2, %3, 0x96;" : "=r"(r) : "r"(a), "r"(b), "r"(c)); return r; }
__device__ __forceinline__ unsigned shf(unsigned a) {
    unsigned r; asm volatile("shf.l.wrap.b32 %0, %1, %1, 7;" : "=r"(r) : "r"(a)); return r; }
// rotazione a 32 bit su pipe FMA: lo = x*2^k ; r = hi(x*2^k) + lo
__device__ __forceinline__ unsigned rotm(unsigned x, unsigned m) {
    unsigned lo, r;
    asm volatile("mul.lo.u32 %0, %1, %2;" : "=r"(lo) : "r"(x), "r"(m));
    asm volatile("mad.hi.u32 %0, %1, %2, %3;" : "=r"(r) : "r"(x), "r"(m), "r"(lo));
    return r;
}
__device__ __forceinline__ unsigned imadlo(unsigned x, unsigned m) {
    unsigned r; asm volatile("mad.lo.u32 %0, %1, %2, %1;" : "=r"(r) : "r"(x), "r"(m)); return r; }

template <int MODE>
__global__ void k(unsigned *out, unsigned iters) {
    if (threadIdx.x == 0) atomicMin(&g_start[smid()], clock64());
    unsigned v[N];
    for (int i = 0; i < N; i++) v[i] = threadIdx.x * 77 + i * 1234567u;
    const unsigned m = c_pow[7];
    for (unsigned it = 0; it < iters; it++) {
#pragma unroll
        for (int i = 0; i < N; i++) {
            unsigned a = v[i], b = v[(i + 1) % N], c = v[(i + 5) % N];
            if (MODE == 0) a = lop(a, b, c);                       // 1 LOP3
            if (MODE == 1) a = shf(a);                             // 1 SHF
            if (MODE == 2) a = imadlo(a, m);                       // 1 IMAD
            if (MODE == 3) a = rotm(a, m);                         // IMAD + IMAD.HI
            if (MODE == 4) a = (i & 1) ? rotm(a, m) : lop(a, b, c);   // mix LOP3 / rot FMA
            if (MODE == 5) a = (i & 1) ? imadlo(a, m) : lop(a, b, c); // mix LOP3 / IMAD
            if (MODE == 6) a = (i % 16 < 11) ? lop(a, b, c) : shf(a);  // mix LOP3 / SHF come nel kernel (~7:3)
            v[i] = a;
        }
    }
    unsigned s = 0;
    for (int i = 0; i < N; i++) s ^= v[i];
    if (s == 0x12345678) out[0] = s;
    __syncthreads();
    if (threadIdx.x == 0) atomicMax(&g_end[smid()], clock64());
}

template <int MODE>
void run(const char *name, unsigned *d, double instr_per_elem) {
    int sms = 0;
    cudaDeviceGetAttribute(&sms, cudaDevAttrMultiProcessorCount, 0);
    const int blocks = sms * 8, tpb = 128;
    const unsigned iters = 4000;
    unsigned long long s[MAX_SM_ID], e[MAX_SM_ID];
    for (int i = 0; i < MAX_SM_ID; i++) { s[i] = ~0ULL; e[i] = 0; }
    cudaMemcpyToSymbol(g_start, s, sizeof s);
    cudaMemcpyToSymbol(g_end, e, sizeof e);
    k<MODE><<<blocks, tpb>>>(d, iters);
    cudaDeviceSynchronize();
    cudaMemcpyFromSymbol(s, g_start, sizeof s);
    cudaMemcpyFromSymbol(e, g_end, sizeof e);
    double cyc = 0;
    for (int i = 0; i < MAX_SM_ID; i++) if (e[i]) cyc += (double)(e[i] - s[i]);
    const double elems = (double)blocks * tpb * iters * N;
    printf("%-34s %6.1f elem/clk/SM   %6.1f istr/clk/SM\n", name, elems / cyc, elems * instr_per_elem / cyc);
}

int main() {
    unsigned *d, pw[32];
    for (int i = 0; i < 32; i++) pw[i] = 1u << i;
    cudaMemcpyToSymbol(c_pow, pw, sizeof pw);
    cudaMalloc(&d, 4);
    for (int rep = 0; rep < 2; rep++) {
        run<0>("LOP3", d, 1);
        run<1>("SHF", d, 1);
        run<2>("IMAD", d, 1);
        run<3>("rot32 via IMAD.SHL+IMAD.HI", d, 2);
        run<4>("mix LOP3 + rot32-IMAD (1:1)", d, 1.5);
        run<5>("mix LOP3 + IMAD (1:1)", d, 1);
        run<6>("mix LOP3 + SHF (11:5, come keccak)", d, 1);
    }
    return 0;
}
