"""Mining onesto di un Seasonal Token: mint(nonce) con keccak256(challenge | sender | nonce) <= target.

Esempi:
  python miner.py --verify-formula                 # verifica on-chain la formula del digest (nessuna tx)
  python miner.py --address 0xTUO --token auto     # mina il token con difficolta minima, solo simulazione
  python miner.py --address 0xTUO --test-bits 230  # prova tutta la pipeline con un target finto e facile
  set PRIVATE_KEY=...  &&  python miner.py --address 0xTUO --send   # invia davvero la tx

La chiave privata viene letta SOLO dalla variabile di ambiente PRIVATE_KEY e mai stampata.
"""
import argparse
import os
import queue
import random
import subprocess
import sys
import threading
import time

from eth_hash.auto import keccak
from web3 import Web3
from web3.exceptions import ContractLogicError

from state import ABI, RPC, TOKENS

HERE = os.path.dirname(os.path.abspath(__file__))
_exe_win = os.path.join(HERE, "keccak_miner.exe")
EXE = _exe_win if os.path.exists(_exe_win) else os.path.join(HERE, "keccak_miner")  # Windows: .exe; Linux: keccak_miner
# endpoint MEV Blocker che non include tx destinate al revert: se qualcun altro mina prima di noi
# e il challenge cambia, non paghiamo gas per una tx fallita
SEND_RPC = os.environ.get("SEND_RPC", "https://rpc.mevblocker.io/noreverts")
MINT_ABI = ABI + [
    {"name": "mint", "type": "function", "stateMutability": "nonpayable",
     "inputs": [{"name": "nonce", "type": "uint256"}], "outputs": [{"type": "bool"}]},
    {"name": "mint", "type": "function", "stateMutability": "nonpayable",
     "inputs": [{"name": "_nonce", "type": "uint256"}, {"name": "_challengeDigest", "type": "bytes32"}],
     "outputs": [{"type": "bool"}]},
]
POLL_S = 12  # un blocco Ethereum
STATUS_EVERY_S = 30   # una riga MH/s ogni 30 s: la coda dei log letta dal supervisore copre ore, non minuti
REEMIT_S = 60         # una soluzione non ancora consumata viene ristampata: non esce mai dalla finestra di log
# RPC di lettura in ordine di preferenza: su 429/timeout il miner passa alla successiva invece di morire
RPCS = [u for u in os.environ.get("ETH_RPCS", "").split(",") if u.strip()] or \
    [RPC, "https://ethereum-rpc.publicnode.com", "https://rpc.mevblocker.io"]

# ---- regole del contratto per il GUARD di invio (identiche a _numberOfRewardsAvailable/_adjustDifficulty) ----
REWARD_INTERVAL = 600     # 1 reward matura ogni 600 s
MAX_AVAIL = 72
# Tetto di reward per mint automatico: con maxNumberOfRewardsPerMint >= 29 la disponibilita resta >= 29
# per sempre e il bot del pool incumbent (soglia minima 29, un anno di storia) puo mintare in ogni momento.
MINT_CAP = int(os.environ.get("MINT_CAP", "28"))
BLOCK_S = 12


SOL_INTERVAL_S = 60       # flotta: circa una soluzione emessa al minuto, non di piu


def min_earned(rate, diff, cap=MINT_CAP, interval=SOL_INTERVAL_S):
    """Soglia E di earned per le soluzioni emesse in flotta: si cerca digest <= target/E cosi che, con
    l hashrate misurato, esca circa una soluzione ogni interval secondi. A difficolta alta E=1 (come
    sempre); sul fondo E sale fino a cap: senza, a D=1e9 una 5090 troverebbe ~7 soluzioni al secondo,
    riavviando la GPU a ogni soluzione (hashrate azzerato) e inondando i log."""
    if rate <= 0 or diff <= 0:
        return 1
    return int(max(1, min(cap, rate * interval // diff)))


def rewards_available(maxper, last, t):
    return min(MAX_AVAIL, max(maxper, (t - last) // REWARD_INTERVAL))


def eases(last, n, t):
    """True se un mint da n reward al tempo t ABBASSA la difficolta: (t-last)*88 >= n*600*61, cioe t-last >= n*416 s."""
    return (t - last) * 88 >= n * REWARD_INTERVAL * 61


def mint_guard(target, maxper, last, digest, t, cap=MINT_CAP):
    """Pura. (ok, n, motivo) per un mint con questo digest incluso al tempo t.
    ok=False se il digest non e valido, se ALZEREBBE la difficolta o se darebbe piu di cap reward."""
    if digest <= 0 or digest > target:
        return False, 0, "digest sopra il target (challenge cambiato o nonce non valido)"
    n = min(target // digest, rewards_available(maxper, last, t))
    if n > cap:
        return False, n, "darebbe %d reward > tetto %d (maxPerMint >= 29 lascia la porta aperta al pool)" % (n, cap)
    if not eases(last, n, t):
        return False, n, "troppo presto: %d reward a %d s dall ultimo mint alzerebbero la difficolta (servono %d s)" % (
            n, t - last, -(-n * REWARD_INTERVAL * 61 // 88))
    return True, n, "ok"


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def digest_of(challenge: bytes, sender: str, nonce: int) -> bytes:
    return keccak(challenge + bytes.fromhex(sender[2:]) + nonce.to_bytes(32, "big"))


class Token:
    def __init__(self, w3, sym):
        self.sym = sym
        self.c = w3.eth.contract(address=Web3.to_checksum_address(TOKENS[sym]), abi=MINT_ABI)
        self.w3 = w3
        self.rpc_i = 0

    def rotate(self):
        """Passa alla RPC successiva di RPCS (dopo un 429 o un timeout)."""
        self.rpc_i = (self.rpc_i + 1) % len(RPCS)
        self.w3 = Web3(Web3.HTTPProvider(RPCS[self.rpc_i], request_kwargs={"timeout": 30}))
        self.c = self.w3.eth.contract(address=self.c.address, abi=MINT_ABI)
        log(f"RPC -> {RPCS[self.rpc_i]}")

    def challenge(self) -> bytes:
        return bytes(self.c.functions.getChallengeNumber().call())

    def target(self) -> int:
        return self.c.functions.getMiningTarget().call()

    def available(self) -> int:
        return self.c.functions.getNumberOfRewardsAvailable(self.w3.eth.get_block("latest")["timestamp"]).call()

    def mint_state(self):
        """(challenge, target, maxNumberOfRewardsPerMint, lastRewardBlockTime, timestamp della testa)."""
        f = self.c.functions
        return (bytes(f.getChallengeNumber().call()), f.getMiningTarget().call(),
                f.maxNumberOfRewardsPerMint().call(), f.lastRewardBlockTime().call(),
                self.w3.eth.get_block("latest")["timestamp"])

    def guard(self, sender, nonce, cap=MINT_CAP):
        """mint_guard sullo stato corrente, per l inclusione nel PROSSIMO blocco."""
        ch, target, maxper, last, ts = self.mint_state()
        d = int.from_bytes(digest_of(ch, sender, nonce), "big")
        return mint_guard(target, maxper, last, d, ts + BLOCK_S, cap)

    def simulate(self, sender, nonce):
        """eth_call di mint(nonce) come se lo inviasse sender: (ok, motivo)."""
        try:
            self.c.functions.mint(nonce).call({"from": sender})
            return True, "ok"
        except ContractLogicError as err:
            return False, str(err)


def rpc_retry(fn, what, wait=15, max_wait=120, on_error=None):
    """Le RPC gratuite rispondono 429/timeout: si ritenta all infinito con attesa crescente invece di
    far morire il miner (un processo morto lascia il container 'running' e fatturato senza minare).
    on_error (es. Token.rotate) viene chiamato dopo ogni errore per cambiare RPC."""
    while True:
        try:
            return fn()
        except Exception as err:
            log(f"RPC {what}: {str(err)[:120]}; ritento tra {wait}s")
            if on_error:
                try:
                    on_error()
                except Exception:
                    pass
            time.sleep(wait)
            wait = min(wait * 2, max_wait)


def pick_token(w3, sym):
    if sym != "auto":
        return Token(w3, sym)
    diffs = {s: Token(w3, s).c.functions.getMiningDifficulty().call() for s in TOKENS}
    for s, d in diffs.items():
        log(f"{s}: difficolta {d:.3e}")
    best = min(diffs, key=diffs.get)
    log(f"scelto {best} (difficolta minima)")
    return Token(w3, best)


def verify_formula(w3):
    """Prova on-chain che la nostra formula del digest coincide con quella del contratto:
    mint(nonce, digest) col digest giusto deve fallire per "larger than mining target"
    (controllo del digest superato), non per "does not match"."""
    sender = "0x000000000000000000000000000000000000dEaD"
    for sym in TOKENS:
        t = Token(w3, sym)
        nonce = random.getrandbits(256)
        d = digest_of(t.challenge(), sender, nonce)
        try:
            t.c.functions.mint(nonce, d).call({"from": sender})
            log(f"{sym}: inatteso, la call non ha fatto revert")
        except ContractLogicError as err:
            ok = "larger than mining target" in str(err)
            log(f"{sym}: " + ("FORMULA OK" if ok else "FORMULA ERRATA") + f"  (revert: {err})")


def replacement_fees(base, prio, prev_prio=0, prev_fee=0):
    """Pura: (mancia, tetto) per un tentativo. Un rilancio con lo stesso nonce e accettato solo se mancia E
    tetto salgono di almeno ~10 percento; se la base fee e scesa, 2*base+mancia darebbe un tetto piu basso
    del precedente ("replacement underpriced"): entrambi restano sempre in salita del 12 percento."""
    prio = max(prio, prev_prio * 112 // 100 + 1) if prev_prio else prio
    fee = max(2 * base + prio, prev_fee * 112 // 100 + 1) if prev_fee else 2 * base + prio
    return prio, fee


def send_mint(w3, token, sender, nonce, cap=MINT_CAP, guard=True):
    """Firma e invia mint(nonce). Con guard=True (default per OGNI invio automatico) rifiuta il mint se
    alzerebbe la difficolta o darebbe piu di cap reward; solo la raffica manuale lo scavalca (bundle)."""
    from eth_account import Account
    key = os.environ.get("PRIVATE_KEY")
    if not key:
        log("PRIVATE_KEY non impostata: niente invio")
        return {"status": None, "error": "PRIVATE_KEY non impostata"}
    acct = Account.from_key(key)
    if acct.address.lower() != sender.lower():
        log("PRIVATE_KEY non corrisponde a --address: il digest dipende da msg.sender, invio annullato")
        return {"status": None, "error": "PRIVATE_KEY non corrisponde all indirizzo"}
    # tip iniziale poco sopra il minimo; se la tx non entra, si rilancia con tip piu alto fino a un tetto.
    prio_gwei = float(os.environ.get("PRIORITY_GWEI", "0.02"))   # mancia di partenza
    max_gwei = float(os.environ.get("MAX_PRIORITY_GWEI", "0.3")) # tetto: non si esagera mai oltre questo
    wait_s = int(os.environ.get("TX_WAIT_S", "45"))              # attesa inclusione per tentativo (~qualche blocco)
    if guard:
        try:
            ok, n, why = token.guard(sender, nonce, cap)
        except Exception as e:
            return {"status": None, "error": "guard: stato on-chain non leggibile: " + str(e)[:120]}
        if not ok:
            log("GUARD: invio bloccato: " + why)
            return {"status": None, "error": "guard: " + why, "guard": True}
    fn = token.c.functions.mint(nonce)
    try:
        gas = int(fn.estimate_gas({"from": sender}) * 1.25)
    except Exception as e:
        log("estimate_gas fallito (soluzione forse gia scaduta): " + str(e))
        return {"status": None, "error": "estimate_gas fallito: " + str(e)[:160]}
    acct_nonce = w3.eth.get_transaction_count(sender)   # stesso nonce di account per tutti i rilanci = tx di sostituzione
    sw3 = Web3(Web3.HTTPProvider(SEND_RPC, request_kwargs={"timeout": 30}))
    try:
        challenge0 = token.challenge()
    except Exception:
        challenge0 = None
    attempt = 0
    sent = []                     # hash di tutti i tentativi: puo entrare uno vecchio, non solo l ultimo
    prev_fee = prev_prio = 0

    def receipt_any():
        for hsh in reversed(sent):
            try:
                rr = w3.eth.get_transaction_receipt(hsh)
            except Exception:
                rr = None
            if rr is not None:
                return hsh, rr
        return None, None
    while prio_gwei <= max_gwei + 1e-9:
        attempt += 1
        if guard and attempt > 1:
            # un rilancio arriva piu tardi: la disponibilita puo essere salita oltre il tetto
            try:
                ok, n, why = token.guard(sender, nonce, cap)
            except Exception:
                ok, why = True, ""
            if not ok:
                log("GUARD: rilancio bloccato: " + why)
                return {"txh": txh, "status": None, "error": "guard al rilancio: " + why, "guard": True}
        base = w3.eth.get_block("latest")["baseFeePerGas"]
        # una sostituzione (stesso nonce) e accettata solo se mancia E tetto salgono di almeno ~10 percento:
        # se la base fee e scesa, 2*base+prio darebbe un tetto PIU BASSO -> "replacement underpriced"
        prio, max_fee = replacement_fees(base, w3.to_wei(round(prio_gwei, 4), "gwei"), prev_prio, prev_fee)
        prev_prio, prev_fee = prio, max_fee
        tx = fn.build_transaction({
            "from": sender, "nonce": acct_nonce, "chainId": 1,
            "gas": gas, "maxPriorityFeePerGas": prio, "maxFeePerGas": max_fee,
        })
        signed = acct.sign_transaction(tx)
        raw = getattr(signed, "raw_transaction", None) or signed.rawTransaction
        try:
            txh = Web3.to_hex(sw3.eth.send_raw_transaction(raw))
        except Exception as e:
            hsh, rc = receipt_any()       # il tentativo precedente puo essere appena entrato ("nonce too low")
            if rc is not None:
                return {"txh": hsh, "status": rc["status"], "block": rc["blockNumber"], "gasUsed": rc["gasUsed"]}
            log("invio fallito (tip %.3f gwei): %s" % (prio_gwei, str(e)[:160]))
            return {"status": None, "error": "invio rifiutato dalla RPC: " + str(e)[:160]}
        sent.append(txh)
        log("tx inviata (tentativo %d, tip %.3f gwei) via %s: %s" % (attempt, prio / 1e9, SEND_RPC, txh))
        deadline = time.time() + wait_s
        while time.time() < deadline:
            hsh, rc = receipt_any()
            if rc is not None:
                log("receipt: status=%s blocco=%s gasUsed=%s" % (rc["status"], rc["blockNumber"], rc["gasUsed"]))
                return {"txh": hsh, "status": rc["status"], "block": rc["blockNumber"], "gasUsed": rc["gasUsed"]}
            if challenge0 is not None:
                try:
                    if token.challenge() != challenge0:
                        # puo essere il NOSTRO mint appena entrato: si ricontrollano le ricevute prima di dire "superata"
                        for _ in range(3):
                            time.sleep(3)
                            hsh, rc = receipt_any()
                            if rc is not None:
                                return {"txh": hsh, "status": rc["status"], "block": rc["blockNumber"],
                                        "gasUsed": rc["gasUsed"]}
                        log("challenge cambiato: soluzione scaduta, smetto di rilanciare")
                        return {"txh": txh, "status": None, "block": None, "gasUsed": 0, "stale": True,
                                "error": "challenge cambiato prima dell inclusione (nessun gas speso)"}
                except Exception:
                    pass
            time.sleep(6)
        prio_gwei = round(prio_gwei * 2 + 0.01, 4)
        if prio_gwei <= max_gwei + 1e-9:
            log("non incluso in %ds -> rilancio con tip piu alto: %.3f gwei" % (wait_s, prio_gwei))
    log("tip massimo (%.3f gwei) raggiunto senza inclusione: rinuncio (nessun gas speso)" % max_gwei)
    return {"status": None, "error": "non inclusa nemmeno col tip massimo %.3f gwei" % max_gwei}


def run_gpu(args, challenge, sender, target):
    cmd = [EXE, "mine", "0x" + challenge.hex(), sender, hex(target), "--tpb", str(args.tpb), "--bpsm", str(args.bpsm)]
    if args.exact_one:
        cmd.append("--exact-one")
    if args.cpu_threads:
        cmd += ["--cpu-threads", str(args.cpu_threads)]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1)
    q = queue.Queue()
    threading.Thread(target=lambda: [q.put(l.strip()) for l in p.stdout], daemon=True).start()
    return p, q


def mine(args, w3):
    token = pick_token(w3, args.token)
    sender = Web3.to_checksum_address(args.address)
    sol_ch, sol_lines, t_reemit = None, [], 0.0   # (earned, riga FLEETSOL) non ancora consumate (stesso challenge)
    t_status, gpu_fail = 0.0, 0
    rate_est = float(os.environ.get("RATE_EST", "5e9"))   # H/s, aggiornato da ogni riga STATUS
    while True:
        challenge = rpc_retry(token.challenge, "challenge", on_error=token.rotate)
        real_target = rpc_retry(token.target, "target", on_error=token.rotate)
        if challenge != sol_ch:          # challenge nuovo: le soluzioni vecchie sono consumate o superate
            sol_ch, sol_lines = challenge, []
        target = (1 << args.test_bits) if args.test_bits else real_target
        diff = (2**256 - 1) // target
        E = min_earned(rate_est, diff) if (args.fleet and not args.test_bits) else 1
        if E > 1:
            target = real_target // E    # digest <= target/E  =>  earned >= E
            log(f"cerco soluzioni con earned >= {E} (~1 al minuto a {rate_est / 1e9:.2f} GH/s)")
        log(f"{token.sym} challenge 0x{challenge.hex()[:16]}..  difficolta {diff:.3e}"
            + ("  [TARGET DI TEST]" if args.test_bits else ""))
        p, q = run_gpu(args, challenge, sender, target)
        t_check = time.time()
        restart = False
        while not restart:
            try:
                line = q.get(timeout=POLL_S)
            except queue.Empty:
                line = ""
            if not line and p.poll() is not None and q.empty():
                gpu_fail += 1
                if gpu_fail > 5:
                    log("processo GPU terminato inaspettatamente 5 volte di fila: esco")
                    return 1
                log("processo GPU terminato inaspettatamente: lo rilancio (%d/5)" % gpu_fail)
                time.sleep(5)
                restart = True
                continue
            if line.startswith("STATUS"):
                gpu_fail = 0
                parts = line.split()   # STATUS totale hash secondi [gpu cpu]
                rate, tot = float(parts[1]) * 1e6, parts[2]
                if rate > 0:
                    rate_est = rate
                if time.time() - t_status >= STATUS_EVERY_S:
                    t_status = time.time()
                    eta = (diff * E / rate / 3600) if rate > 0 else float("inf")
                    log(f"{rate / 1e6:7.1f} MH/s  {int(tot) / 1e12:8.3f} TH provati  "
                        f"tempo medio atteso per soluzione {eta:.2f} h")
            elif line.startswith("FOUND"):
                _, nonce_hex, dig_hex = line.split()
                nonce = int(nonce_hex, 16)
                d = digest_of(challenge, sender, nonce)
                dv = int.from_bytes(d, "big")
                if d.hex() != dig_hex[2:] or dv > target:
                    log("soluzione GPU NON verificata in Python (digest diverso o sopra il target): scartata")
                    restart = True
                    continue
                earned = real_target // dv if dv else 0
                if args.fleet:
                    # FLEET: emette SUBITO (digest gia verificato <= target), senza RPC/simulate locali
                    # che potrebbero perderla; il PC (submit.py) riverifica sulla sfida corrente prima di firmare.
                    sol = f"FLEETSOL {token.sym} 0x{challenge.hex()} {nonce_hex} {dig_hex} earned={earned}"
                    print(sol, flush=True)
                    # si tengono le 4 con earned piu alto (crociera: serve earned >= k) + la piu recente
                    best = sorted(sol_lines, key=lambda x: -x[0])[:4]
                    sol_lines = best + [(earned, sol)]
                    t_reemit = time.time()
                    log(f"SOLUZIONE (fleet) nonce={nonce_hex} earned={earned}")
                    try:
                        with open(os.path.join(HERE, "solutions.log"), "a") as f:
                            print(time.ctime(), token.sym, f"nonce={nonce_hex}", f"earned={earned}", file=f)
                    except Exception:
                        pass
                    restart = True
                    continue
                avail = token.available()
                with open(os.path.join(HERE, "solutions.log"), "a") as f:
                    print(time.ctime(), token.sym, f"challenge=0x{challenge.hex()}", f"sender={sender}",
                          f"nonce={nonce_hex}", f"digest={dig_hex}", file=f)
                log(f"SOLUZIONE nonce={nonce_hex}")
                log(f"  digest={dig_hex}  rewards={min(earned, avail)} (earned {earned}, disponibili {avail})")
                if token.challenge() != challenge:
                    log("  challenge cambiato nel frattempo: soluzione scaduta, riparto")
                    restart = True
                    continue
                ok, why = token.simulate(sender, nonce)
                log("  simulazione eth_call mint(nonce): " + ("OK" if ok else "REVERT " + why))
                if args.fleet:
                    # riga canonica letta dal supervisore sul PC; nessun invio dall istanza (niente chiave privata)
                    if ok:
                        print(f"FLEETSOL {token.sym} 0x{challenge.hex()} {nonce_hex} {dig_hex} earned={earned}", flush=True)
                    restart = True   # continua a minare sul prossimo challenge, non terminare
                    continue
                if ok and args.send:
                    send_mint(w3, token, sender, nonce)
                elif ok:
                    log("  pronta: rilancia con --send (e PRIVATE_KEY) oppure chiama mint(nonce) dal tuo wallet SUBITO")
                p.kill()
                return 0
            if time.time() - t_check >= POLL_S:
                t_check = time.time()
                try:
                    if token.challenge() != challenge:
                        log("challenge cambiato (qualcuno ha mintato): riavvio GPU sul nuovo challenge")
                        restart = True
                except Exception as err:  # RPC momentaneamente giu: continuo a minare e cambio RPC
                    log(f"RPC: {str(err)[:120]}")
                    token.rotate()
                if not restart and sol_lines and time.time() - t_reemit >= REEMIT_S:
                    t_reemit = time.time()
                    for _e, sol in sol_lines:   # ancora valide (challenge invariato): restano nella coda dei log
                        print(sol, flush=True)
        p.kill()


JOB_S = 20          # rotazione: durata massima di un job sulla GPU prima di ricontrollare la catena
MAX_HOLD_S = 1800   # rotazione: dopo questo tempo una soluzione non consumata non blocca piu il token


def pick_weighted(state, rnd, floor_share=0.1):
    """Pura: token da minare fra quelli senza una nostra soluzione in attesa, con probabilita proporzionale
    alla difficolta (= lavoro: tutti i token avanzano allo stesso ritmo) ma con una quota minima, cosi un
    token sul fondo (crociera) non resta mai senza GPU. state = {sym: (difficolta, gia_risolto)}."""
    opts = {k: d for k, (d, solved) in state.items() if not solved and d > 0}
    if not opts:
        return None
    mx = max(opts.values())
    w = {k: max(d, floor_share * mx) for k, d in opts.items()}
    r = rnd.random() * sum(w.values())
    for k in sorted(w):
        r -= w[k]
        if r <= 0:
            return k
    return sorted(w)[-1]


def mine_rotation(args, w3):
    """Flotta a ROTAZIONE: una GPU serve tutti i token di --tokens. Appena trova una soluzione per un token
    (che il PC trattiene fino ai 416 s) passa a un altro invece di restare a minare un challenge gia risolto:
    niente GPU ferme ad aspettare, e sul fondo una sola GPU basta per tutti i token. Usa keccak_miner batch
    (un processo, job da JOB_S s, nessun riavvio CUDA). Stampa le stesse righe FLEETSOL e MH/s della
    modalita a token singolo, quindi supervisore e submit.py non cambiano."""
    syms = [x.strip().upper() for x in args.tokens.split(",") if x.strip()]
    for x in syms:
        if x not in TOKENS:
            raise SystemExit("token sconosciuto: " + x)
    sender = Web3.to_checksum_address(args.address)
    toks = {x: Token(w3, x) for x in syms}
    st = {x: {"ch": None, "target": 0, "solved_at": None, "lines": []} for x in syms}
    rnd = random.Random()
    rate_est = float(os.environ.get("RATE_EST", "5e9"))
    rate_known = False      # finche non c e una misura vera, la prima la sostituisce (niente media col default)
    t_status = t_reemit = t_full = 0.0
    proc, seq, fails = None, 0, 0

    def refresh(x):
        tk = toks[x]
        ch = rpc_retry(tk.challenge, x + " challenge", on_error=tk.rotate)
        tg = (1 << args.test_bits) if args.test_bits else rpc_retry(tk.target, x + " target", on_error=tk.rotate)
        y = st[x]
        if ch != y["ch"]:          # challenge nuovo: le nostre soluzioni vecchie sono consumate o superate
            y["ch"], y["solved_at"], y["lines"] = ch, None, []
        y["target"] = tg

    log("rotazione su " + ",".join(syms) + " (job da %d s, rilascio dopo %d s)" % (JOB_S, MAX_HOLD_S))
    while True:
        now = time.time()
        if now - t_full >= 60:
            t_full = now
            for x in syms:
                refresh(x)
        if proc is None or proc.poll() is not None:
            proc = subprocess.Popen([EXE, "batch", sender, "--tpb", str(args.tpb), "--bpsm", str(args.bpsm)],
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                    text=True, bufsize=1)
            if proc.stdout.readline().strip() != "READY":
                fails += 1
                proc.kill()
                proc = None
                if fails > 5:
                    log("keccak_miner batch non parte: esco")
                    return 1
                log("keccak_miner batch non pronto, riprovo (%d/5)" % fails)
                time.sleep(5)
                continue
        state = {}
        for x in syms:
            y = st[x]
            held = y["solved_at"] is not None and now - y["solved_at"] < MAX_HOLD_S
            state[x] = ((2 ** 256 - 1) // y["target"] if y["target"] else 0, held)
        cur = pick_weighted(state, rnd)
        if cur is None:                        # tutti i token hanno una nostra soluzione in attesa
            time.sleep(POLL_S)
            for x in syms:
                refresh(x)
        else:
            y = st[cur]
            diff = (2 ** 256 - 1) // y["target"]
            E = 1 if args.test_bits else min_earned(rate_est, diff)
            gt = y["target"] // E
            seq += 1
            jid = "%s-%d" % (cur, seq)
            t0 = time.time()
            try:
                proc.stdin.write("%s 0x%s %s %d\n" % (jid, y["ch"].hex(), hex(gt), JOB_S))
                proc.stdin.flush()
                line = proc.stdout.readline()
            except (OSError, ValueError):      # processo GPU morto fra un job e l altro: pipe rotta
                line = ""
            if not line:
                fails += 1
                log("processo GPU terminato inaspettatamente: lo rilancio (%d/5)" % fails)
                proc = None
                if fails > 5:
                    return 1
                time.sleep(5)
                continue
            fails = 0
            p = line.split()
            if p[0] == "FOUND" and len(p) >= 4:
                try:
                    hl = proc.stdout.readline().split()   # HASHES <id> <hash>: hashrate reale anche sui job risolti
                except (OSError, ValueError):
                    hl = []
                el = time.time() - t0
                if len(hl) >= 3 and hl[0] == "HASHES" and el > 0.5 and int(hl[2]) > 0:
                    r_now = int(hl[2]) / el
                    rate_est = r_now if not rate_known else 0.8 * rate_est + 0.2 * r_now
                    rate_known = True
            if p[0] == "TIMEOUT" and len(p) >= 3:
                el = time.time() - t0
                if el > 1.0 and int(p[2]) > 0:
                    rate_est = int(p[2]) / el
                    rate_known = True
            elif p[0] == "FOUND" and len(p) >= 4:
                nonce = int(p[2], 16)
                d = digest_of(y["ch"], sender, nonce)
                dv = int.from_bytes(d, "big")
                if d.hex() == p[3][2:] and dv <= gt:
                    earned = y["target"] // dv if not args.test_bits else 0
                    sol = f"FLEETSOL {cur} 0x{y['ch'].hex()} {p[2]} {p[3]} earned={earned}"
                    print(sol, flush=True)
                    log(f"SOLUZIONE (fleet, rotazione) {cur} nonce={p[2]} earned={earned}")
                    y["lines"] = sorted(y["lines"], key=lambda q: -q[0])[:4] + [(earned, sol)]
                    y["solved_at"] = time.time()
                else:
                    log("soluzione GPU NON verificata in Python: scartata")
            refresh(cur)
        now = time.time()
        if now - t_status >= STATUS_EVERY_S:
            t_status = now
            log(f"{rate_est / 1e6:7.1f} MH/s  rotazione: " + " ".join(
                f"{x}{'*' if st[x]['solved_at'] else ''}" for x in syms))
        if now - t_reemit >= REEMIT_S:
            t_reemit = now
            for x in syms:
                for _e, sol in st[x]["lines"]:   # challenge invariato (refresh azzera le vecchie)
                    print(sol, flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--token", default="auto", choices=["auto", *TOKENS])
    ap.add_argument("--address", help="address che chiamera mint (msg.sender)")
    ap.add_argument("--send", action="store_true", help="invia davvero la tx (richiede PRIVATE_KEY)")
    ap.add_argument("--fleet", action="store_true", help="modalita istanza remota: stampa FLEETSOL e continua, mai invio")
    ap.add_argument("--tokens", default="",
                    help="con --fleet: ROTAZIONE su piu token (es. SPRING,SUMMER,AUTUMN,WINTER), una GPU li serve tutti")
    ap.add_argument("--exact-one", action="store_true",
                    help="accetta solo digest in (target/2, target] -> esattamente 1 reward (raddoppia il tempo atteso)")
    ap.add_argument("--test-bits", type=int, default=0, help="target finto 2^N per provare la pipeline (es. 230)")
    ap.add_argument("--verify-formula", action="store_true")
    ap.add_argument("--cpu-threads", type=int, default=0,
                    help="thread CPU AVX2 in aggiunta alla GPU (misurato: circa +3%% a caldo, ma piu calore)")
    ap.add_argument("--tpb", type=int, default=128)
    ap.add_argument("--bpsm", type=int, default=16)
    args = ap.parse_args()
    w3 = Web3(Web3.HTTPProvider(RPC, request_kwargs={"timeout": 30}))
    if args.verify_formula:
        return verify_formula(w3)
    if not args.address:
        ap.error("--address obbligatorio")
    if args.tokens:
        if not args.fleet:
            ap.error("--tokens (rotazione) solo con --fleet")
        return mine_rotation(args, w3)
    return mine(args, w3)


if __name__ == "__main__":
    sys.exit(main() or 0)
